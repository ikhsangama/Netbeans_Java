package jdbc.dao.transferobject;

public class Kamus {

    private String indo;
    private String eng;

    public String getIndo() {
        return indo;
    }

    public void setIndo(String indo) {
        this.indo = indo;
    }

    public String getEng() {
        return eng;
    }

    public void setEng(String eng) {
        this.eng = eng;
    }

    
}
