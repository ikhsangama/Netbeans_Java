package jdbc.dao.dao;

import jdbc.dao.utilities.MysqlUtilities;
import jdbc.dao.transferobject.Kamus;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Indra Waspada
 */
public class KamusDAOMysql {

    Connection koneksi = MysqlUtilities.getConnection();

    public Kamus createKamusObject() {
        return new Kamus();
    }

    public void insert(Kamus kamus) {
        Statement statement = null;
        try {
            statement = koneksi.createStatement();
            String sql = "INSERT INTO kamus(indo, eng) VALUES ('" + kamus.getIndo() + "','" + kamus.getEng() + "');";
            if (statement.executeUpdate(sql) > 0) {
                System.out.println("Berhasil insert");
            } else {
                System.out.println("Gagal insert");
            }
        } catch (SQLException ex) {
            System.out.println("Gagal membuat statement : " + ex.getMessage());
        } finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (Exception e) {
                    System.out.println("Gagal menutup statement");
                }
            }
        }
    }

    public void update(Kamus kamus) {
        Statement statement = null;
        try {
            statement = koneksi.createStatement();
            String sql = "UPDATE kamus SET eng='" + kamus.getEng() + "' WHERE indo='"+kamus.getIndo()+"'";
            if (statement.executeUpdate(sql) > 0) {
                System.out.println("Berhasil update");
            } else {
                System.out.println("Gagal update");
            }
        } catch (SQLException ex) {
            System.out.println("Gagal membuat statement : " + ex.getMessage());
        } finally {
            if (statement != null) {
                try {
                    statement.close();
                    System.out.println("Sukses menutup statement");
                } catch (Exception e) {
                    System.out.println("Gagal menutup statement");
                }
            }
        }
    }

    public void delete(String indo) {
        Statement statement = null;
        try {
            String sql = "DELETE from kamus WHERE indo = '" + indo + "'";
            statement = koneksi.createStatement();
            statement.executeUpdate(sql);
        } catch (SQLException ex) {
            System.out.println("Gagal membuat statement : " + ex.getMessage());
        } finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (Exception e) {
                    System.out.println("Gagal menutup statement");
                }
            }
        }
    }

    public Kamus selectByIndo(String indo) {
        Statement statement = null;
        ResultSet result = null;
        Kamus kamus = null;

        try {
            statement = koneksi.createStatement();
            String sql = "SELECT * from kamus WHERE indo = '" + indo + "';";
            result = statement.executeQuery(sql);

            if (result.next()) {
                kamus = new Kamus();
                kamus.setIndo(result.getString("indo"));
                kamus.setEng(result.getString("eng"));

            }

            return kamus;

        } catch (SQLException ex) {
            System.out.println("Gagal membuat statement : " + ex.getMessage());
            return kamus;
        } finally {
            if (statement != null) {
                try {
                    statement.close();
                    System.out.println("Sukses menutup statement");
                } catch (Exception e) {
                    System.out.println("Gagal menutup statement");
                }
            }
            if (result != null) {
                try {
                    result.close();
                } catch (SQLException ex) {
                    System.out.println(ex);
                }
            }
        }
    }

    public List<Kamus> selectAll() {
        Statement statement = null;
        ResultSet result = null;
        List<Kamus> kamuss = new ArrayList<>();

        try {
            statement = koneksi.createStatement();
            String sql = "SELECT * from kamus;";
            result = statement.executeQuery(sql);

            while (result.next()) {
                Kamus kamus = new Kamus();
                kamus.setIndo(result.getString("indo"));
                kamus.setEng(result.getString("eng"));

                kamuss.add(kamus);
            }
            return kamuss;

        } catch (SQLException ex) {
            System.out.println("Gagal membuat statement : " + ex.getMessage());
            return kamuss;
        } finally {
            if (statement != null) {
                try {
                    statement.close();
                    System.out.println("Sukses menutup statement");
                } catch (Exception e) {
                    System.out.println("Gagal menutup statement");
                }
            }
            if (result != null) {
                try {
                    result.close();
                } catch (SQLException ex) {
                    System.out.println(ex);
                }
            }
        }
    }
}
