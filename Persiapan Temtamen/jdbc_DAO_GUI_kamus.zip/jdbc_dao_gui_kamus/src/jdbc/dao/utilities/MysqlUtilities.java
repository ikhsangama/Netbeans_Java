package jdbc.dao.utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MysqlUtilities {

    private static Connection koneksi;

    public static Connection getConnection() {
        if (koneksi == null) {
            try {
                try {
                    Class.forName("com.mysql.jdbc.Driver");
                } catch (ClassNotFoundException ex) {
                    System.out.println("error : " + ex.getMessage());
                }
                String url = "jdbc:mysql://localhost:3306/jdbc_kamus";
                String user = "student";
                String password = "rahasia";
                koneksi = DriverManager.getConnection(url, user, password);
                System.out.println("Koneksi Sukses");
            } catch (SQLException ex) {
                System.out.println("Koneksi Gagal...." + ex.getMessage());
            }
        }
        return koneksi;
    }
}
